from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_user, name='login'),
    path('signup/', views.signup_user, name='signup'),
    path('logout/', views.logout_user, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('admin-panel/', views.admin_panel, name='admin_panel'),
    path('user-home/', views.user_home, name='user_home'),
    path('update/', views.update_user, name='update_user'),
    path('update-password/', views.update_password, name='update_password'),
    path('product/<int:pk>/', views.product, name='product'),
]
